class CellSelectionTest {
    constructor() {
        this.data = [];
        this.selectedCells = new Set(); // 用于存储选中的细胞名称
        this.colors = {
            'Heart': '#d4b365',
            'Neural crest': '#5B9BD5',
            'Branchial arch': '#70AD47',
            'AGM': '#00B050',
            'Liver': '#FF6D01',
            'Cavity': '#404040',
            'Blood vessel': '#E1819E',
            'Brain': '#8B4513',
            'Connective tissue': '#9966CC',
            'Dermomyotome': '#FF69B4',
            'Head mesenchyme': '#20B2AA',
            'Lung primordium': '#FF4500',
            'Mesenchyme': '#DAA520',
            'Notochord': '#4682B4',
            'Sclerotome': '#32CD32',
            'Spinal cord': '#8A2BE2',
            'Surface ectoderm': '#FF1493',
            'Urogenital ridge': '#00CED1'
        };
        this.init();
    }

    async init() {
        await this.loadData();
        this.render();
    }

    async loadData() {
        try {
            const response = await fetch('./js/components/pathSelection/Path/cellcount.csv');
            const csvText = await response.text();
            const lines = csvText.trim().split('\n');
            const headers = lines[0].split(',');

            this.data = lines.slice(1).map(line => {
                const values = line.split(',');
                return {
                    annotation: values[0],
                    time1: parseInt(values[1]),
                    time2: parseInt(values[2]),
                    total: parseInt(values[3]),
                    ratio: parseFloat(values[4])
                };
            });

            this.data.sort((a, b) => b.ratio - a.ratio);
            console.log('数据加载完成:', this.data);
        } catch (error) {
            console.error('加载数据失败:', error);
        }
    }

    render() {
        const container = d3.select('#cellSelectionContainer');
        container.selectAll('*').remove();

        const header = container.append('div')
            .attr('class', 'cell-selection-header');

        header.append('h2')
            .text('Cell Selection');

        const cellList = container.append('div')
            .attr('class', 'cell-list');

        this.cellList = cellList;
        this.updateItems();
    }

    updateItems() {
        const items = this.cellList.selectAll('.cell-item')
            .data(this.data, d => d.annotation);

        const itemsEnter = items.enter()
            .append('div')
            .attr('class', 'cell-item')
            .on('click', (event, d) => {
                if (this.selectedCells.has(d.annotation)) {
                    this.selectedCells.delete(d.annotation);
                } else {
                    this.selectedCells.add(d.annotation);
                }
                this.updateSelection();
                this.triggerSelectionChange(); // 触发选中状态变化事件
            });

        const itemsUpdate = itemsEnter.merge(items);

        itemsUpdate.selectAll('.cell-color').remove();
        itemsUpdate.selectAll('.cell-name').remove();
        itemsUpdate.selectAll('.cell-percentage').remove();
        itemsUpdate.selectAll('.cell-distribution').remove();

        itemsUpdate.append('div')
            .attr('class', 'cell-color')
            .style('background-color', d => this.colors[d.annotation] || '#999');

        itemsUpdate.append('div')
            .attr('class', 'cell-name')
            .text(d => d.annotation);

        itemsUpdate.append('div')
            .attr('class', 'cell-percentage')
            .text(d => `${(d.ratio * 100).toFixed(1)}%`);

        const distributionDiv = itemsUpdate.append('div')
            .attr('class', 'cell-distribution');

        const chartContainer = distributionDiv.append('div')
            .attr('class', 'chart-container');

        itemsUpdate.each((d, i, nodes) => {
            const element = d3.select(nodes[i]).select('.chart-container');
            const svg = element.append('svg')
                .attr('width', 100)
                .attr('height', 20)
                .datum(d);

            this.createDistributionChart(svg);
        });

        items.exit().remove();
        this.updateSelection();
    }

    createDistributionChart(container) {
        const width = 100; // SVG 宽度
        const height = 20; // SVG 高度

        container.each((data, i, nodes) => {
            const element = d3.select(nodes[i]);
            const svg = element.append('svg')
                .attr('width', width)
                .attr('height', height);

            const distributionData = this.generateDistributionData(data);

            const xScale = d3.scaleLinear()
                .domain([0, 1])
                .range([0, width]);

            const yScale = d3.scaleLinear()
                .domain([0, d3.max(distributionData, dd => dd.value)])
                .range([height, 0]);

            const area = d3.area()
                .x(dd => xScale(dd.position))
                .y0(height)
                .y1(dd => yScale(dd.value))
                .curve(d3.curveBasis);

            svg.append('path')
                .datum(distributionData)
                .attr('fill', this.colors[data.annotation] || '#999')
                .attr('fill-opacity', 0.7)
                .attr('stroke', this.colors[data.annotation] || '#999')
                .attr('stroke-width', 1)
                .attr('d', area);

            // 添加分隔线，表示两个时间点的分布
            svg.append('line')
                .attr('x1', width / 2)
                .attr('x2', width / 2)
                .attr('y1', 0)
                .attr('y2', height)
                .attr('stroke', '#ccc')
                .attr('stroke-width', 1)
                .attr('stroke-dasharray', '2,2');
        });
    }

    generateDistributionData(cellData) {
        const points = 3; // 增加点数以获得更平滑的曲线
        const data = []; // 初始化存储分布数据的数组

        // 计算 time1 和 time2 的比例
        const total = cellData.time1 + cellData.time2;
        const time1Ratio = cellData.time1 / total;
        const time2Ratio = cellData.time2 / total;

        // 遍历生成分布曲线上的每个点
        for (let i = 0; i <= points; i++) {
            const position = i / points; // 当前点的位置（0 到 1 之间）
            let value = 0; // 当前点的值（分布曲线的高度）

            // 使用线性插值计算当前点的值
            value = position < 0.5 ? time1Ratio * (2 * position) : time2Ratio * (2 * position - 1);

            // 存储当前点的数据
            data.push({
                position: position,
                value: Math.max(0, value) // 确保值不小于 0
            });
        }

        return data; // 返回生成的分布数据
    }

    updateSelection() {
        this.cellList.selectAll('.cell-item')
            .classed('selected', d => this.selectedCells.has(d.annotation));
    }

    triggerSelectionChange() {
        // 触发自定义事件，通知其他脚本选中状态已改变
        const event = new CustomEvent('cellSelectionChange', {
            detail: {
                selectedCells: Array.from(this.selectedCells) // 将选中的细胞名称数组传递出去
            }
        });
        document.dispatchEvent(event); // 改为 document.dispatchEvent
        console.log('触发细胞选择事件:', Array.from(this.selectedCells)); // 添加调试日志
    }
}

document.addEventListener('DOMContentLoaded', () => {
    new CellSelectionTest();
});