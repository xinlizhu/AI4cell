import { LineageChart } from './LineageChart.js';

class LineageVis {
    constructor(containerId) {
        this.container = d3.select(containerId);
        this.registerEventListeners();
    }

    registerEventListeners() {
        // 监听 PathView.js 发出的路径选择事件
        document.addEventListener('pathSelected', (event) => {
            const selectedPathData = event.detail.selectedPath;
            if (selectedPathData && selectedPathData.length > 0) {
                const pathString = selectedPathData[0].path_string;
                this.renderPath(pathString);
            }
        });
    }

    renderPath(pathString) {
        // 清空现有内容
        this.container.selectAll('*').remove();

        // 解析路径字符串，例如 "A -> B -> C"
        const cellNodes = pathString.split(' -> ').map(s => s.trim());

        // 为每个细胞节点创建图表
        cellNodes.forEach((cellName, index) => {
            // 如果不是第一个图表，在前面添加一个箭头
            if (index > 0) {
                this.container.append('div')
                    .attr('class', 'lineage-arrow')
                    .html('&rarr;');
            }

            // 创建一个包装器 div，包含标题和图表容器
            const wrapper = this.container.append('div')
                .attr('class', 'lineage-chart-wrapper');

            // 添加标题
            wrapper.append('div')
                .attr('class', 'chart-title')
                .text(cellName);

            // 创建图表的容器
            const chartContainerId = `lineage-chart-${index}`;
            wrapper.append('div').attr('id', chartContainerId);

            // 实例化并绘制图表
            new LineageChart(chartContainerId, cellName);
        });
    }
}

// 确保在 DOM 加载完成后再初始化
document.addEventListener('DOMContentLoaded', () => {
    new LineageVis('#lineageVisContainer');
});