// 细胞通讯强度可视化 - 可复用组件 (已修正)

export class LineageChart {
    // 构造函数接收容器ID和细胞名称
    constructor(containerId, cellName) {
        this.containerId = containerId;
        this.cellName = cellName;
        this.baseRadius = 60;
        this.minInnerRadius = 45;
        this.maxOuterRadius = 75;
        this.maxInnerExtension = this.baseRadius - this.minInnerRadius; // 15
        this.maxOuterExtension = this.maxOuterRadius - this.baseRadius; // 15
        this.width = 180;
        this.height = 180;
        this.centerX = this.width / 2;
        this.centerY = this.height / 2;
        
        this.colorScale = d3.scaleOrdinal(d3.schemeCategory10);
        
        this.init();
    }
    
    init() {
        this.svg = d3.select(`#${this.containerId}`)
            .append('svg')
            .attr('width', this.width)
            .attr('height', this.height);
        
        this.g = this.svg.append('g')
            .attr('transform', `translate(${this.centerX}, ${this.centerY})`);
        
        // Tooltip现在是全局的，我们只需要选择它或创建它
        this.tooltip = d3.select('body').select('.lineage-tooltip');
        if (this.tooltip.empty()) {
            this.tooltip = d3.select('body').append('div')
                .attr('class', 'lineage-tooltip')
                .style('opacity', 0)
                .style('position', 'absolute')
                .style('pointer-events', 'none')
                .style('background', 'rgba(0,0,0,0.7)')
                .style('color', 'white')
                .style('padding', '8px')
                .style('border-radius', '4px')
                .style('font-size', '12px');
        }
        
        this.loadData();
    }
    
    async loadData() {
        try {
            // 【修正】修正数据加载路径
            const totalPath = `./js/components/pathSelection/Every_cell_info/${this.cellName}/${this.cellName}_total.csv`;
            const cellPath = `./js/components/pathSelection/Every_cell_info/${this.cellName}/${this.cellName}.csv`;

            const totalData = await d3.csv(totalPath, d3.autoType);
            const cellData = await d3.csv(cellPath, d3.autoType);
            
            this.colorScale.domain(cellData.map(d => d.cell_type));
            
            this.processData(totalData, cellData);
            this.drawChart();
            this.drawCenterChart(cellData); // 绘制中心图
            
        } catch (error) {
            console.error(`数据加载失败 for ${this.cellName}:`, error);
            this.g.append('text')
                .attr('text-anchor', 'middle')
                .attr('dy', '0.3em')
                .text('无数据')
                .style('font-size', '12px')
                .style('fill', '#999');
        }
    }
    
    processData(totalData, cellData) {
        // 【修正】根据基础名称过滤掉所有同源细胞，而不仅仅是自身
        const getBaseName = (name) => name.split('_')[0].toLowerCase();
        const centerBaseName = getBaseName(this.cellName);
        
        const nonCenterCells = cellData.filter(d => getBaseName(d.cell_type) !== centerBaseName);
        const totalCells = d3.sum(nonCenterCells, d => d.cell_num);
        
        const maxSendIntensity = d3.max(totalData, d => d.发送总强度) || 1;
        const maxReceiveIntensity = d3.max(totalData, d => d.接收总强度) || 1;
        
        let tempData = [];
        nonCenterCells.forEach(cellInfo => {
            const commData = totalData.find(d => d.邻居细胞.toLowerCase() === cellInfo.cell_type.toLowerCase());
            const proportion = totalCells > 0 ? (cellInfo.cell_num / totalCells) : 0;

            if (commData) {
                tempData.push({
                    cellType: cellInfo.cell_type,
                    cellNum: cellInfo.cell_num,
                    proportion: proportion,
                    arcLength: 2 * Math.PI * proportion,
                    sendExtension: (commData.发送总强度 / maxSendIntensity) * this.maxOuterExtension,
                    receiveExtension: (commData.接收总强度 / maxReceiveIntensity) * this.maxInnerExtension,
                    sendIntensity: commData.发送总强度,
                    receiveIntensity: commData.接收总强度,
                    totalIntensity: commData.通讯总强度,
                    sendChannels: commData.发送通道数,
                    receiveChannels: commData.接收通道数,
                    sendAvgIntensity: commData.发送平均强度,
                    receiveAvgIntensity: commData.接收平均强度,
                    color: this.colorScale(cellInfo.cell_type),
                    hasComm: true, // 标记有通讯
                });
            } else {
                // 【新增】即使没有通讯数据，也添加条目
                tempData.push({
                    cellType: cellInfo.cell_type,
                    cellNum: cellInfo.cell_num,
                    proportion: proportion,
                    arcLength: 2 * Math.PI * proportion,
                    sendExtension: 0,
                    receiveExtension: 0,
                    sendIntensity: 0,
                    receiveIntensity: 0,
                    totalIntensity: 0,
                    sendChannels: 0,
                    receiveChannels: 0,
                    sendAvgIntensity: 0,
                    receiveAvgIntensity: 0,
                    color: this.colorScale(cellInfo.cell_type),
                    hasComm: false, // 标记无通讯
                });
            }
        });
        
        // 【修正】确保按通讯总强度排序
        tempData.sort((a, b) => b.totalIntensity - a.totalIntensity);
        
        let currentAngle = -Math.PI / 2; // 从12点钟方向开始
        this.data = [];
        tempData.forEach(d => {
            this.data.push({ ...d, startAngle: currentAngle, endAngle: currentAngle + d.arcLength });
            currentAngle += d.arcLength;
        });
    }
    
    drawChart() {
        this.g.append('circle')
            .attr('r', this.baseRadius)
            .attr('fill', 'none')
            .attr('stroke', '#ddd')
            .attr('stroke-width', 1);
        
        const arc = d3.arc();
        this.data.forEach(d => {
            if (d.hasComm) {
                // 【原有逻辑】对有通讯的细胞正常绘制内外环
                // 接收强度弧 (内环)
                this.g.append('path')
                    .attr('d', arc.innerRadius(this.baseRadius - d.receiveExtension).outerRadius(this.baseRadius).startAngle(d.startAngle).endAngle(d.endAngle))
                    .attr('fill', d.color)
                    .attr('stroke', 'white')
                    .attr('stroke-width', 0.5)
                    .on('mouseover', (event, _) => this.showTooltip(event, d, '接收'))
                    .on('mouseout', () => this.hideTooltip());

                // 发送强度弧 (外环)
                this.g.append('path')
                    .attr('d', arc.innerRadius(this.baseRadius).outerRadius(this.baseRadius + d.sendExtension).startAngle(d.startAngle).endAngle(d.endAngle))
                    .attr('fill', d.color)
                    .attr('fill-opacity', 0.5)
                    .attr('stroke', 'white')
                    .attr('stroke-width', 0.5)
                    .on('mouseover', (event, _) => this.showTooltip(event, d, '发送'))
                    .on('mouseout', () => this.hideTooltip());
            } else {
                // 【新增逻辑】对无通讯的细胞只绘制一条细线
                this.g.append('path')
                    .attr('d', arc.innerRadius(this.baseRadius - 0.5).outerRadius(this.baseRadius + 0.5).startAngle(d.startAngle).endAngle(d.endAngle))
                    .attr('fill', '#eee') // 使用灰色填充
                    .on('mouseover', (event, _) => this.showTooltip(event, d, '无通讯'))
                    .on('mouseout', () => this.hideTooltip());
            }
        });
    }

    drawCenterChart(cellData) {
        // 【修正】参照fig1.js并结合现有逻辑，完善中心图
        const getBaseName = (name) => name.split('_')[0].toLowerCase();
        const centerBaseName = getBaseName(this.cellName);

        // 找到中心细胞（可能不止一个，例如'Cavity'和'Cavity_2_20'都属于'cavity'组）
        const centerCells = cellData.filter(d => getBaseName(d.cell_type) === centerBaseName);
        if (centerCells.length === 0) return;
        // 使用第一个找到的中心细胞作为连线的起点
        const mainCenter = centerCells[0]; 

        // 邻居细胞是所有不同基础名称的细胞
        const neighbors = cellData.filter(d => getBaseName(d.cell_type) !== centerBaseName);
        
        // 参与布局的细胞包括所有邻居和中心细胞
        const layoutCells = [...neighbors, ...centerCells];

        const xExtent = d3.extent(layoutCells, d => d.x);
        const yExtent = d3.extent(layoutCells, d => d.y);
        const span = Math.max(xExtent[1] - xExtent[0], yExtent[1] - yExtent[0]);
        const scale = span === 0 ? 1 : 40 / span; // 缩放到40像素范围内

        const tx = d => (d.x - d3.mean(xExtent)) * scale;
        const ty = d => (d.y - d3.mean(yExtent)) * scale;
        
        const rScale = d3.scaleSqrt().domain(d3.extent(layoutCells, d => d.cell_num)).range([1, 5]);
        
        const centerGroup = this.g.append('g').attr('class', 'center-chart');
        
        centerGroup.append('circle')
            .attr('r', 40)
            .attr('fill', 'none')
            .attr('stroke', '#ccc')
            .attr('stroke-width', 0.5);

        // 绘制从主中心点到所有邻居的连线
        centerGroup.selectAll('.center-link').data(neighbors).join('line')
            .attr('x1', tx(mainCenter)).attr('y1', ty(mainCenter))
            .attr('x2', d => tx(d)).attr('y2', d => ty(d))
            .attr('stroke', '#555').attr('stroke-width', 0.5)
            .attr('stroke-dasharray', '1,1');
        
        // 绘制所有参与布局的细胞节点
        centerGroup.selectAll('.center-dot').data(layoutCells).join('circle')
            .attr('cx', d => tx(d)).attr('cy', d => ty(d))
            .attr('r', d => rScale(d.cell_num))
            .attr('fill', d => this.colorScale(d.cell_type))
            .attr('stroke', '#fff')
            .attr('stroke-width', 0.2);
    }

    // 【新增】Tooltip显示/隐藏功能
    showTooltip(event, data, type) {
        let content = `<strong>${data.cellType}</strong><br/>细胞数量: ${data.cellNum}<br/>占比: ${(data.proportion * 100).toFixed(1)}%`;

        if (data.hasComm) {
            const intensity = type === '发送' ? data.sendIntensity : data.receiveIntensity;
            const channels = type === '发送' ? data.sendChannels : data.receiveChannels;
            const avgIntensity = type === '发送' ? data.sendAvgIntensity : data.receiveAvgIntensity;
            content += `<hr style="margin: 4px 0; border-color: #555;">
                        ${type}强度: ${intensity.toFixed(3)}<br/>
                        ${type}通道数: ${channels}<br/>
                        平均强度: ${avgIntensity.toFixed(4)}<br/>
                        总通讯强度: ${data.totalIntensity.toFixed(3)}`;
        } else {
            content += `<hr style="margin: 4px 0; border-color: #555;">无通讯数据`;
        }

        this.tooltip
            .style('opacity', 1)
            .style('left', (event.pageX + 10) + 'px')
            .style('top', (event.pageY - 28) + 'px')
            .html(content);
    }

    hideTooltip() {
        this.tooltip.style('opacity', 0);
    }
}