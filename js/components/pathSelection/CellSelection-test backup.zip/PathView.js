// 读取 CSV 文件
const csvFilePath = './js/components/pathSelection/Path/paths_summary.csv';

// 用于存储路径数据
let pathsData = [];

// 用于存储选中的细胞
let selectedCells = [];

// 确保在 DOM 加载完成后再注册事件监听器
document.addEventListener('DOMContentLoaded', () => {
    console.log('PathView.js DOM 加载完成，注册事件监听器');
    
    // 监听 cellSelectionChange 事件
    document.addEventListener('cellSelectionChange', (event) => {
        selectedCells = event.detail.selectedCells || [];
        console.log('PathView.js 接收到细胞选择变化:', selectedCells);
        updateVisualization();
    });
    
    // 初始化可视化
    initializeVisualization();
});

// 初始化可视化
function initializeVisualization() {
    console.log('初始化可视化');
    // 初始化容器
    initializeContainer();
    
    d3.csv(csvFilePath).then(data => {
        pathsData = data;
        console.log('加载的路径数据:', pathsData);
        
        // 初始显示所有路径
        updateVisualization();
    }).catch(error => {
        console.error('加载CSV文件失败:', error);
    });
}

// 初始化容器
function initializeContainer() {
    // 【修改点 1】: 将目标容器从 #cellSelectionContainer 改为 #pathViewContainer
    const container = d3.select('#pathViewContainer');

    // 清除现有内容
    container.selectAll('*').remove();
    
    // 在新的容器中创建路径列表
    container
        .append('div')
        .attr('class', 'path-list-container')
        .style('max-height', '600px')
        .style('overflow-y', 'auto')
        .style('padding', '10px');
}

// 根据选中的细胞筛选路径
function filterPathsBySelectedCells(data) {
    if (!selectedCells || selectedCells.length === 0) {
        return data; // 如果没有选中细胞，显示所有路径
    }
    
    return data.filter(path => {
        // 【修改】: 将 .some() 改为 .every()
        // 这样可以确保路径字符串包含所有选中的细胞类型
        return selectedCells.every(cellType => 
            path.path_string.toLowerCase().includes(cellType.toLowerCase())
        );
    });
}

// 更新可视化
function updateVisualization() {
    console.log('更新可视化，当前选中细胞:', selectedCells);
    
    if (!pathsData || pathsData.length === 0) {
        console.log('路径数据为空，跳过更新');
        return;
    }
    
    // 筛选路径
    const filteredPaths = filterPathsBySelectedCells(pathsData);
    console.log('筛选后的路径:', filteredPaths);
    
    // 【修改点 2】: 明确指定从 #pathViewContainer 中查找 .path-list-container
    // 这样可以确保我们操作的是正确的元素
    const container = d3.select('#pathViewContainer .path-list-container');
    
    // 清除现有内容
    container.selectAll('*').remove();
    
    if (filteredPaths.length === 0) {
        container.append('p')
            .style('color', '#999')
            .style('text-align', 'center')
            .text('没有找到匹配的路径');
        return;
    }
    
    // 添加标题
    container.append('h3')
        .style('margin-bottom', '15px')
        .text(`找到 ${filteredPaths.length} 条路径`);
    
    // 创建路径列表
    const pathItems = container.selectAll('.path-item')
        .data(filteredPaths)
        .enter()
        .append('div')
        .attr('class', 'path-item')
        .style('border', '1px solid #ddd')
        .style('border-radius', '5px')
        .style('margin-bottom', '10px')
        .style('padding', '10px')
        .style('background-color', '#f9f9f9')
        .style('cursor', 'pointer')
        .on('click', function(event, d) {
            console.log('点击路径:', d);
            triggerPathSelection([d]);
            
            // 高亮选中的路径
            container.selectAll('.path-item')
                .style('background-color', '#f9f9f9')
                .style('border-color', '#ddd');
            
            d3.select(this)
                .style('background-color', '#e3f2fd')
                .style('border-color', '#2196f3');
        });
    
    // 添加路径ID
    pathItems.append('div')
        .style('font-weight', 'bold')
        .style('color', '#333')
        .style('margin-bottom', '5px')
        .text(d => `路径 ${d.path_id}`);
    
    // 添加路径详细信息
    pathItems.append('div')
        .style('font-size', '12px')
        .style('color', '#666')
        .style('margin-bottom', '8px')
        .text(d => `长度: ${d.length} | 权重: ${d.weight} | 起点: ${d.start_node} | 终点: ${d.end_node}`);
    
    // 添加路径字符串（高亮匹配的细胞类型）
    pathItems.append('div')
        .style('font-size', '14px')
        .style('line-height', '1.4')
        .html(d => highlightSelectedCells(d.path_string));
}

// 高亮显示选中的细胞类型
function highlightSelectedCells(pathString) {
    if (!selectedCells || selectedCells.length === 0) {
        return pathString;
    }
    
    let highlightedString = pathString;
    
    selectedCells.forEach(cellType => {
        const regex = new RegExp(`(${cellType})`, 'gi');
        highlightedString = highlightedString.replace(regex, 
            '<span style="background-color: #ffeb3b; color: #d84315; font-weight: bold;">$1</span>'
        );
    });
    
    return highlightedString;
}

// 触发路径选择事件
function triggerPathSelection(selectedPath) {
    const event = new CustomEvent('pathSelected', {
        detail: {
            selectedPath: selectedPath
        }
    });
    document.dispatchEvent(event);
    console.log('触发路径选择事件:', selectedPath);
}